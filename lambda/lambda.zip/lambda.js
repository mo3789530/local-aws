exports.handler = async (event, context) => {

    const response = {

        statusCode: 200, // HTTP 200 OK
    };

    return response;
};